const express=require("express");
 const app=express();
const mysql = require('mysql2');

console.log("express done");

app.use(express.static("sf"));

app.get("/blur",(req,res)=>{

    console.log("ajax fucntion called");

    const dbobject={
        host:"localhost",
        user:"root",
        password:"cdac",
        database:"world",
        port:3306,

        
    }
    const connection=mysql.createConnection(dbobject);
    let output={status:false, detail:{bookid:0,bname:"",price:0},
};

let x=req.query.bookid;

console.log(x+" "+y+" "+z+" ");
connection.query("select * from book where bookid=?",[x],(error,data)=>{
    if(error){
        console.log("error in connection");

    }
    else{
        if(data.length > 0){
            output.status=true;
            output.detail=data[0];
        }
        res.send(output);
    }

    
    
});


app.get("/update",(req,res)=>{

    console.log("ajax fucntion called");

    const dbobject={
        host:"localhost",
        user:"root",
        password:"cdac",
        database:"world",
        port:3306,

        
    }
    const connection=mysql.createConnection(dbobject);
    let output={status:false}


let x=req.query.bookid;
let y=req.query.bname;
let z=req.query.price;
console.log(x+" "+y+" "+z+" ");
connection.query("update book set bname=? ,price=? where pin=?",[y,z,x],(error,data)=>{
    if(error){
        console.log("error in connection");

    }
    else{
        if(data.affectedRows > 0){
            output.status=true;
            
        }
        res.send(output);
    }

}
);

app.listen(400,()=>{
    console.log("server...");
});
