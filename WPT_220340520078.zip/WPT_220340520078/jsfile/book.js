const express=require("express");
 const app=express();
const mysql = require("mysql2");

console.log("express done");

app.use(express.static("sf"));

app.get("/bookdetails",(req,resd)=>{

    console.log("ajax fucntion called");

    const dbobject={
        host:"localhost",
        user:"root",
        password:"cdac",
        database:"world",
        port:3306,

        
    }
    const connection=mysql.createConnection(dbobject);
    let output={status:false, detail:{bookid:0,bname:"",price:0},};

let x=req.query.bookid;
let y=req.query.bname;
let z=req.query.price;
console.log(x+" "+y+" "+z+" ");
connection.query("select bookid,bname,price from book where bookid=?",[x],(error,rows)=>{
    if(error){
        console.log("error in connection");

    }
    else{
        if(rows.length>0){
            output.status=true;
            output.detail=rows[0];

        }
        else{
            console.log("no error");
        }
    }
    console.log(output);
    resd.send(output);
});
});
app.listen(400,()=>{
    console.log("server...");
})
