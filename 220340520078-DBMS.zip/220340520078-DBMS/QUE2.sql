USE Module_Exam;

create table tempp(
  result varchar(70)
  
);
DROP TABLE TEMPP;
delimiter //
CREATE PROCEDURE PROC1(string1 varchar(20),string2 varchar(20)) 
begin
if instr(string2,string1)!=0 then
insert into tempp values('first varchar string exists inside the varchar string');
else
insert into tempp values('first varchar string not exists inside the varchar string');
end if;
end; //
delimiter ;

call proc1('DAC','CDAC');
SELECT * FROM TEMPP;
DROP PROCEDURE PROC1;